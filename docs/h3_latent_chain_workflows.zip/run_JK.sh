#!/bin/sh
cd /opt/data/cache/output/h3_mask_cont
O=/opt/data/cache/output/rofan_office
export REFS=$O/duke/sheet_s22_202.png,$O/prince/sheet_s22_101.png,$O/plate_krea_s41.png,$O/plate_door_s52.png
export PROMPT_FILE=/opt/data/cache/output/h3_mask_cont/cut6_end_prompt_v3_noref.txt DUR=8 SEED=6602 MP=0.5 RATIO=16:9 W=960 H=544 UPSCALE=0
export MODE=latent PREFIX_LATENT=C2_cut5_s5501_x2_p1_video.latent PREFIX_TOKENS=7
OUT=J_vonly_s6602.mp4 python3 run_mask2.py > J.log 2>&1
AUDIO_PREFIX_LATENT=C2_cut5_s5501_x2_p1_audio.latent OUT=K_vaudio_s6602.mp4 python3 run_mask2.py > K.log 2>&1
touch JK.flag
