#!/usr/bin/env python3
"""video_deno_ref continuation with upscale (Pass1 + Pass2).
env: REFS PROMPT_FILE DUR SEED MP RATIO W H OUT UPSCALE(0/1)
  MODE=guide   PREFIX_VIDEO (5f clip; AddGuide on Pass1 and, with UPSCALE, a second guide on the upscaled latent for Pass2)
  MODE=latent  PREFIX_LATENT (Pass1 video latent in ComfyUI input/), PREFIX_TOKENS (default 7 = 22 frames),
               optional PREFIX_LATENT2 (Pass2 video latent): replaces the upscaled prefix before Pass2 and masks it
  SAVE_LATENT=1 saves Pass1 (362) and, with UPSCALE, Pass2 (358) video+audio latents; after the run they are
               downloaded next to OUT and uploaded to ComfyUI input/ as <tag>_p1_video.latent / <tag>_p2_video.latent
  DRYRUN=1 writes <OUT>.api.json only."""
import json, os, sys, time, subprocess, urllib.request, urllib.parse
H = "http://192.168.0.5:8188"
E = os.environ
p = json.load(open(E.get("API", "/opt/data/scripts/deno_ref_api_20261101e.json")))
def up(path, name=None):
    if E.get("DRYRUN"): return os.path.basename(path)
    args = ["curl", "-s", "-F", f"image=@{path}" + (f";filename={name}" if name else ""), "-F", "overwrite=true", H + "/upload/image"]
    r = json.loads(subprocess.check_output(args))
    return (r["subfolder"] + "/" if r.get("subfolder") else "") + r["name"]
r2v = p["365"]["inputs"]
for k in [k for k in r2v if k.startswith(("ref_images.", "ref_videos.", "ref_video_audios.", "ref_audios."))]: del r2v[k]
for n in ("233", "260", "261", "262"): p.pop(n, None)
for i, f in enumerate(E["REFS"].split(",")):
    nid = str(900 + i); p[nid] = {"class_type": "LoadImage", "inputs": {"image": up(f)}}
    r2v[f"ref_images.ref_image_{i}"] = [nid, 0]
r2v["prompt"] = open(E["PROMPT_FILE"]).read().strip()
rw, rh = E.get("RATIO", "16:9").split(":")
p["342"]["inputs"].update(ratio_width=int(rw), ratio_height=int(rh), megapixels=float(E.get("MP", "0.5")))
dur = float(E.get("DUR", "8"))
p["343"]["inputs"]["duration"] = dur
p["344"]["inputs"]["noise_seed"] = int(E.get("SEED", "1"))
upscale = E.get("UPSCALE", "0") == "1"
p["349"]["inputs"]["switch"] = upscale
W, Hh = int(E["W"]), int(E["H"]); W2, H2 = W * 2, Hh * 2
fr = round(dur * 24)
while fr % 17 != 5: fr += 1
T = (fr - 5) // 17 * 5 + 2
out = E["OUT"]; tag = os.path.splitext(os.path.basename(out))[0]
mode = E.get("MODE", "latent")
if E.get("PREFIX_VIDEO"):
    p["920"] = {"class_type": "LoadVideo", "inputs": {"file": up(E["PREFIX_VIDEO"])}}
    p["921"] = {"class_type": "GetVideoComponents", "inputs": {"video": ["920", 0]}}
if E.get("SAVE_LATENT"):  # core SaveLatent cannot write the nested AV latent: split first
    p["940"] = {"class_type": "LTXVSeparateAVLatent", "inputs": {"av_latent": ["362", 1]}}
    p["941"] = {"class_type": "SaveLatent", "inputs": {"samples": ["940", 0], "filename_prefix": f"latents/maskcont/{tag}_p1_video"}}
    p["942"] = {"class_type": "SaveLatent", "inputs": {"samples": ["940", 1], "filename_prefix": f"latents/maskcont/{tag}_p1_audio"}}
    if upscale:
        p["943"] = {"class_type": "LTXVSeparateAVLatent", "inputs": {"av_latent": ["358", 1]}}
        p["944"] = {"class_type": "SaveLatent", "inputs": {"samples": ["943", 0], "filename_prefix": f"latents/maskcont/{tag}_p2_video"}}
        p["945"] = {"class_type": "SaveLatent", "inputs": {"samples": ["943", 1], "filename_prefix": f"latents/maskcont/{tag}_p2_audio"}}
def mask(nid, w, h, P):
    p[nid] = {"class_type": "CreateFadeMaskAdvanced", "inputs": {"points_string": f"0:(0.0),\n{P}:(1.0)\n", "invert": False,
              "frames": T, "width": w // 16, "height": h // 16, "interpolation": "none"}}
def P_frames(P): return (P - 2) // 5 * 17 + 5  # tokens -> frames (5m+2 tokens = 17m+5 frames)
if mode == "guide":
    p["922"] = {"class_type": "MiniMaxH3AddGuide", "inputs": {"positive": ["370", 0], "latent": ["365", 1], "frame_idx": 0, "vae": ["340", 2], "image": ["921", 0]}}
    p["359"]["inputs"]["conditioning"] = ["922", 0]; p["355"]["inputs"]["conditioning"] = ["922", 0]
    if upscale:
        p["923"] = {"class_type": "MiniMaxH3AddGuide", "inputs": {"positive": ["370", 0], "latent": ["356:346", 0], "frame_idx": 0, "vae": ["340", 2], "image": ["921", 0]}}
        p["355"]["inputs"]["conditioning"] = ["923", 0]
elif mode == "latent":
    P = int(E.get("PREFIX_TOKENS", "7")); assert P % 5 == 2
    print(f"frames={fr} tokens={T} prefix_tokens={P} p1={E['PREFIX_LATENT']} p2={E.get('PREFIX_LATENT2')}", flush=True)
    # Pass1: [saved Pass1 tail | empty] cut to T, video mask 0 on the prefix
    p["930"] = {"class_type": "LTXVSeparateAVLatent", "inputs": {"av_latent": ["365", 1]}}
    p["932"] = {"class_type": "LoadLatent", "inputs": {"latent": E["PREFIX_LATENT"]}}
    p["933"] = {"class_type": "LatentCut", "inputs": {"samples": ["932", 0], "dim": "t", "index": -P, "amount": P}}
    p["934"] = {"class_type": "LatentConcat", "inputs": {"samples1": ["933", 0], "samples2": ["930", 0], "dim": "t"}}
    p["935"] = {"class_type": "LatentCut", "inputs": {"samples": ["934", 0], "dim": "t", "index": 0, "amount": T}}
    mask("936", W, Hh, P)
    p["937"] = {"class_type": "SetLatentNoiseMask", "inputs": {"samples": ["935", 0], "mask": ["936", 0]}}
    audio_src = ["930", 1]
    if E.get("AUDIO_PREFIX_LATENT"):  # audio latent [1,32,2,Ta], 40 ticks/s: prefix = last A ticks of the saved Pass1 audio, masked 0
        Ta = round(fr / 24 * 40); A = int(E.get("AUDIO_TICKS", str(round(P_frames(P) / 24 * 40 + 0.5))))
        print(f"audio ticks={Ta} prefix_ticks={A} from {E['AUDIO_PREFIX_LATENT']}", flush=True)
        p["960"] = {"class_type": "LoadLatent", "inputs": {"latent": E["AUDIO_PREFIX_LATENT"]}}
        p["961"] = {"class_type": "LatentCut", "inputs": {"samples": ["960", 0], "dim": "x", "index": -A, "amount": A}}
        p["962"] = {"class_type": "LatentConcat", "inputs": {"samples1": ["961", 0], "samples2": ["930", 1], "dim": "x"}}
        p["963"] = {"class_type": "LatentCut", "inputs": {"samples": ["962", 0], "dim": "x", "index": 0, "amount": Ta}}
        p["964"] = {"class_type": "SolidMask", "inputs": {"value": 1.0, "width": Ta, "height": 2}}
        p["965"] = {"class_type": "SolidMask", "inputs": {"value": 0.0, "width": A, "height": 2}}
        p["966"] = {"class_type": "MaskComposite", "inputs": {"destination": ["964", 0], "source": ["965", 0], "x": 0, "y": 0, "operation": "multiply"}}
        p["967"] = {"class_type": "SetLatentNoiseMask", "inputs": {"samples": ["963", 0], "mask": ["966", 0]}}
        audio_src = ["967", 0]
    p["938"] = {"class_type": "LTXVConcatAVLatent", "inputs": {"video_latent": ["937", 0], "audio_latent": audio_src}}
    p["362"]["inputs"]["latent_image"] = ["938", 0]
    if upscale and E.get("PREFIX_LATENT2"):
        # Pass2: upscaled AV latent (audio already masked 0 by 356:348) -> replace video prefix with the saved Pass2 tail, mask it 0
        p["950"] = {"class_type": "LTXVSeparateAVLatent", "inputs": {"av_latent": ["356:346", 0]}}
        p["951"] = {"class_type": "LoadLatent", "inputs": {"latent": E["PREFIX_LATENT2"]}}
        p["952"] = {"class_type": "LatentCut", "inputs": {"samples": ["951", 0], "dim": "t", "index": -P, "amount": P}}
        p["953"] = {"class_type": "LatentCut", "inputs": {"samples": ["950", 0], "dim": "t", "index": P, "amount": T - P}}
        p["954"] = {"class_type": "LatentConcat", "inputs": {"samples1": ["952", 0], "samples2": ["953", 0], "dim": "t"}}
        mask("955", W2, H2, P)
        p["956"] = {"class_type": "SetLatentNoiseMask", "inputs": {"samples": ["954", 0], "mask": ["955", 0]}}
        p["957"] = {"class_type": "LTXVConcatAVLatent", "inputs": {"video_latent": ["956", 0], "audio_latent": ["950", 1]}}
        p["358"]["inputs"]["latent_image"] = ["957", 0]
p["357"]["inputs"]["filename_prefix"] = "Local/maskcont/" + tag
json.dump(p, open(out + ".api.json", "w"), indent=1)
if E.get("DRYRUN"): print("dryrun ok"); sys.exit(0)
req = urllib.request.Request(H + "/prompt", data=json.dumps({"prompt": p}).encode(), headers={"Content-Type": "application/json"})
try: pid = json.load(urllib.request.urlopen(req))["prompt_id"]
except urllib.error.HTTPError as e: open(out + ".fail", "w").write(e.read().decode()); sys.exit(1)
json.dump({"prompt_id": pid}, open(out + ".job.json", "w")); print("pid", pid, flush=True)
t0 = time.time()
while True:
    time.sleep(5)
    h = json.load(urllib.request.urlopen(f"{H}/history/{pid}"))
    if pid in h and (h[pid].get("outputs") or h[pid].get("status", {}).get("status_str") == "error"): break
st = h[pid].get("status", {})
got = False
for nid, node in h[pid].get("outputs", {}).items():
    for lt in node.get("latents", []):
        q = urllib.parse.urlencode({"filename": lt["filename"], "subfolder": lt["subfolder"], "type": "output"})
        kind = {"941": "p1_video", "942": "p1_audio", "944": "p2_video", "945": "p2_audio"}[nid]
        local = os.path.join(os.path.dirname(os.path.abspath(out)), f"{tag}_{kind}.latent")
        urllib.request.urlretrieve(f"{H}/view?{q}", local)
        print("latent", up(local, os.path.basename(local)), os.path.getsize(local), flush=True)
    for im in node.get("images", []) + node.get("videos", []) + node.get("gifs", []):
        if im.get("type") == "output" and im["filename"].endswith(".mp4"):
            q = urllib.parse.urlencode({"filename": im["filename"], "subfolder": im["subfolder"], "type": "output"})
            urllib.request.urlretrieve(f"{H}/view?{q}", out); got = True
if got:
    open(out + ".done", "w").write(f"{time.time()-t0:.0f}s"); print("done", out, f"{time.time()-t0:.0f}s"); sys.exit(0)
open(out + ".fail", "w").write(json.dumps(st)[:3000]); print("fail", st)
