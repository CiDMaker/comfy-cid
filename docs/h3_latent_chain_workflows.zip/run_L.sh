#!/bin/sh
# 3-segment chain: C2 (cut5) -> K (cut6, re-run with SAVE_LATENT) -> L (cut7)
cd /opt/data/cache/output/h3_mask_cont
O=/opt/data/cache/output/rofan_office
export REFS=$O/duke/sheet_s22_202.png,$O/prince/sheet_s22_101.png,$O/plate_krea_s41.png,$O/plate_door_s52.png
export DUR=8 MP=0.5 RATIO=16:9 W=960 H=544 UPSCALE=0 MODE=latent PREFIX_TOKENS=7
[ -f K_vaudio_s6602_p1_video.latent ] || PROMPT_FILE=$PWD/cut6_end_prompt_v3_noref.txt SEED=6602 PREFIX_LATENT=C2_cut5_s5501_x2_p1_video.latent AUDIO_PREFIX_LATENT=C2_cut5_s5501_x2_p1_audio.latent SAVE_LATENT=1 OUT=K_vaudio_s6602.mp4 python3 run_mask2.py > K.log 2>&1
[ -f K_vaudio_s6602_p1_video.latent ] || { touch L.fail; exit 1; }
PROMPT_FILE=$PWD/cut7_after_prompt_v1.txt SEED=7701 PREFIX_LATENT=K_vaudio_s6602_p1_video.latent AUDIO_PREFIX_LATENT=K_vaudio_s6602_p1_audio.latent SAVE_LATENT=1 OUT=L_cut7_s7701.mp4 python3 run_mask2.py > L.log 2>&1
touch L.flag
