검증에 쓴 워크플로 (API 포맷, 노드 id 기반; ComfyUI Load로 열면 자동 배치되거나 POST /prompt 로 바로 실행)
기반 그래프: /opt/data/scripts/deno_ref_api_20261101e.json (video_deno_ref 11-01 저장본)

K_vaudio_s6602.mp4.api.json  : 드래프트, video prefix(930~938) + audio prefix(960~967) + latent 저장(940~942). cut5(C2) -> cut6
L_cut7_s7701.mp4.api.json    : 위와 같은 구조로 K -> cut7 (3단 연쇄의 마지막)
H_p1p2_s6602_x2.mp4.api.json : x2 final, Pass1 prefix(930~938) + Pass2 prefix(950~957, 업스케일 뒤) + p1/p2 latent 저장
I_noref_s6602.mp4.api.json   : 드래프트, video prefix만, 이전 영상 ref 없음

노드 역할
 930 LTXVSeparateAVLatent (R2V 365 out1)      950 Separate (업스케일 356:346)
 932 LoadLatent prev p1 video                  951 LoadLatent prev p2 video
 933 LatentCut t -7,7   934 LatentConcat t     952/953/954 Cut/Cut/Concat
 935 LatentCut t 0,T    936 CreateFadeMaskAdvanced (0..6 = 0)   955 mask
 937 SetLatentNoiseMask 938 LTXVConcatAVLatent -> 362.latent_image   956/957 -> 358.latent_image
 960 LoadLatent prev p1 audio  961 LatentCut x -37,37  962 Concat x  963 Cut x 0,Ta
 964 SolidMask 1 (Ta x 2)  965 SolidMask 0 (37 x 2)  966 MaskComposite multiply  967 SetLatentNoiseMask
 940~945 Separate + SaveLatent (p1/p2 video, audio)
LoadLatent 의 파일은 ComfyUI input/ 에 있어야 함 (러너가 /upload/image 로 올림).
러너: run_mask2.py (env 설명은 파일 머리), 실행 예: run_JK.sh, run_L.sh
